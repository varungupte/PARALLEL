#include<unistd.h>
#include<bits/stdc++.h>
#include<omp.h>
#define THREADS 4
#define N 16

int main()
{
	int i;
	double time=omp_get_wtime();
	#pragma omp parallel for schedule(guided) num_threads(THREADS)
	for (i = 0; i < N; i++)
	{
		/* wait for i seconds */
		sleep(i);
		printf("Thread %d has completed iteration %d.\n", omp_get_thread_num(),i);
	}
	printf(" in %lf seconds\n",omp_get_wtime()-time);
	/* all threads done */
	printf("All done!\n");
	return 0;
}

//g++  q-1-guided-iterations.cpp -fopenmp
//Time Taken is :- 36002334 microseconds