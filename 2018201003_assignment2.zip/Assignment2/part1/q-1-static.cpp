#include<unistd.h>
#include<bits/stdc++.h>
#include<omp.h>
using namespace std;
#define THREADS 10
#define N 100000000

int main() 
{
	int i;
	double time=omp_get_wtime();
	cout<<"Running "<<N<<" iterations on "<<THREADS<<" threads statically."<<endl;
	#pragma omp parallel for schedule(static) num_threads(THREADS)
	for (i = 0; i < N; i++) 
	{
	/* a loop that doesn’t take very long */
	}
	/* all threads done */
	printf(" in %lf seconds\n",omp_get_wtime()-time);
	cout<<"All done!\n";
	return 0;
}

// g++ q-1-static.cpp -fopenmp
// Time taken is :- 92360 microseconds