#include<unistd.h>
#include<bits/stdc++.h>
#include<omp.h>
using namespace std;
#define THREADS 10
#define N 100000000

int main() 
{
	int i;
	double time=omp_get_wtime();
	cout<<"Running "<<N<<" iterations on "<<THREADS<<" threads dynamically."<<endl;
	// #pragma omp parallel for schedule(dynamic) num_threads(THREADS)
	#pragma omp parallel for schedule(dynamic,100) num_threads(THREADS)
	for (i = 0; i < N; i++) 
	{
	/* a loop that doesn’t take very long */
	}
	/* all threads done */
	printf(" in %lf seconds\n",omp_get_wtime()-time);
	cout<<"All done!\n";
	return 0;
}

// g++ q-1-dynamic.cpp -fopenmp
//Time taken is:- 4012062 microseconds
//Time taken is:- 112310 microseconds using schedule(dynamic,100)