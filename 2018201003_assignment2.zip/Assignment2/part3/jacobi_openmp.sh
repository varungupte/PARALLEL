#! /bin/bash
#
g++ -c -Wall -fopenmp heat.cpp solver-jacobi.cpp
# g++ -o heat heat.cpp solver-jacobi.cpp
if [ $? -ne 0 ]; then
  echo "Compile error."
  exit
fi
#
g++ -fopenmp -o heat heat.o solver-jacobi.o -lm
if [ $? -ne 0 ]; then
  echo "Load error."
  exit
fi
#
#  Request 1 thread.
#
echo "Run with 1 thread."
export OMP_NUM_THREADS=1
time ./heat 24 0.001 >> jacobi_openmp1.txt
#
#  Request 2 threads.
#
echo "Run with 2 threads."
export OMP_NUM_THREADS=2
time ./heat 24 0.001 >> jacobi_openmp2.txt
#
#  Request 4 threads.
#
echo "Run with 4 threads."
export OMP_NUM_THREADS=4
time ./heat 24 0.001 >> jacobi_openmp3.txt
#
#  Request 6 threads.
#
echo "Run with 6 threads."
export OMP_NUM_THREADS=6
time ./heat 24 0.001 >> jacobi_openmp4.txt
#
#  Discard the executable.
#
rm heat
#
echo "Normal end of execution."
