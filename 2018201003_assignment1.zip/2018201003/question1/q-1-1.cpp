#include <bits/stdc++.h>
#include <time.h>
using namespace std;

void initialize(int m, int n , vector<vector<unsigned long long> > &A)
{
	for(int i=0 ; i<m ; i++)
	{
		for(int j=0 ; j<n ; j++)
		{
			A[i][j] = rand() % 1000;
		}	
	}	
}
void initialize_output(int m, int n , vector<vector<unsigned long long> > &A)
{
	for(int i=0 ; i<m ; i++)
	{
		for(int j=0 ; j<n ; j++)
		{
			A[i][j] = 0;
		}	
	}	
}
void multi_mat(int m, int n, int p, vector<vector<unsigned long long> > &A, vector<vector<unsigned long long> > &B)
{
	vector < vector<unsigned long long int> > C(m , vector<unsigned long long> (p));
	
	initialize_output(m,p,C);
	
	//multiplying matrices
	for(int i=0 ; i<m ; i++)
	{
		for(int j=0 ; j<p ; j++)
		{
			for(int k=0 ; k<n ;k++)
			{
				C[i][j] += A[i][k]*B[k][j];
			}
		}
	}

	cout<<"\nThis resultant matrix is:-\n";
	for(int i=0 ; i<m ; i++)
	{
		for(int j=0 ; j<p ; j++)
		{
			cout<<C[i][j]<<"	";
		}	
		cout<<endl;
	}	

}

int main()
{
	srand(time(NULL));

	int n,m,p;

	// generating the dimensions
	n = (rand() % 5) + 2;
	m = rand() % 6 + 2;
	p = rand() % 6 + 2;

	//Decalaring the matrices A and B
	vector < vector<unsigned long long int> > A(m , vector<unsigned long long> (n));
	vector < vector<unsigned long long int> > B(n , vector<unsigned long long> (p));
	
	
	// initializing the matrices
	initialize(m,n,A);
	initialize(n,p,B);

	cout<<"dimensions of A are:-"<<m<<"*"<<n<<endl;
	cout<<"dimensions of B are:-"<<n<<"*"<<p<<endl;


	
	cout<<"\nMatrix A is:-\n";
	for(int i=0 ; i<m ; i++)
	{
		for(int j=0 ; j<n ; j++)
		{
			cout<<A[i][j]<<"	";
		}	
		cout<<endl;
	}	

	cout<<"\nMatrix B is:-\n";
	for(int i=0 ; i<n; i++)
	{
		for(int j=0 ; j<p ; j++)
		{
			cout<<B[i][j]<<"	";
		}	
		cout<<endl;
	}	
	//multiplying the matrices and printing the results
	multi_mat(m,n,p,A,B);
	return 0;
}