#include <bits/stdc++.h>
#include <time.h>
using namespace std;

int max_val = 10;  // values in matrix

int main()
{
	srand(time(NULL));

	int n,m,p,p1,p2,q1,q2,temp;

	cout<<"Enter the shape of matrix A:-";
	cin>>m>>n;

	cout<<"Enter the shape of matrix B:-";
	cin>>n>>p;

	cout<<"\nEnter lower and upper bandwidth of matrix A:-";
	cin>>p1>>q1;
	
	cout<<"\nEnter lower and upper bandwidth of matrix B;-";
	cin>>p2>>q2;

	unsigned long long int A[p1 + q1 + 1][n];
	unsigned long long int B[p2 + q2 + 1][p];
	unsigned long long int C[m][p];
	long long int A_actual[m][n];
	long long int B_actual[n][p];

	//initializing matrix A 
	for(int i=0 ; i<p1+q1+1 ; i++)
	{
		for(int j=0 ; j<n ; j++)
		{
			A[i][j] = 0;
		}
	}
	for(int i=0;i<m;i++)
	{
		for(int j=0;j<n;j++)
		{
			temp = rand() % max_val;
				if(j<=i+q1&&j>=i-p1)
				{
					if(i>j)
					{
						A[q1+i-j][j]=temp;;
					}
					else
					{
						A[q1+i-j][i]=temp;
					}
				}
		}
	}
	//initializing matrix B
	for(int i=0 ; i<p2+q2+1 ; i++)
	{
		for(int j=0 ; j<p ; j++)
		{
			B[i][j] = 0;
		}
	}
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<p;j++)
		{
			temp = rand() % max_val;
				if(j<=i+q2&&j>=i-p2)
				{
					if(i>j)
					{
						B[q2+i-j][j]=temp;;
					}
					else
					{
						B[q2+i-j][i]=temp;
					}
				}
		}
	}

	
	//printing the matrix A
	cout<<"**********************************************"<<endl;
	cout<<"\nThe matrix A is:-\n";
	for(int i=0 ; i<m ; i++)
	{
		for(int j=0 ; j<n ; j++)
		{
			if(j<=i+q1&&j>=i-p1)
			{
				if(i>j)
				{
					cout<<A[q1+i-j][j]<<"	";
				}
				else
				{
					cout<<A[q1+i-j][i]<<"	";
				}
			}
			else
			{
				cout<<"0	";
			}
		}	
		cout<<endl;
	}	

	cout<<"**********************************************"<<endl;
	// // printing the matrix B
	cout<<"\nThe matrix B is:-\n";
	for(int i=0 ; i<n ; i++)
	{
		for(int j=0 ; j<p; j++)
		{
			if(j<=i+q2&&j>=i-p2)
			{
				if(i>j)
				{
					cout<<B[q2+i-j][j]<<"	";
				}
				else
				{
					cout<<B[q2+i-j][i]<<"	";
				}
			}
			else
			{
				cout<<"0	";
			}
		}	
		cout<<endl;
	}	

	//Initializing reultant matrix C
	for(int i=0 ; i<m ; i++)
	{
		for(int j=0 ; j<p ; j++)
		{
			C[i][j] = 0;
		}
	}
	
	//C=A*B
	for(int i=0 ; i<m ; i++)
		for(int j=0 ; j<p ; j++)
			for(int k=0 ; k<n ;k++)
			{
				int aik , bkj;

				if(((i - k + q1) < 0) || ((i-k+q1) >= m))
					aik = 0;
				else
				{	
					if(k<=i+q1&&k>=i-p1)
					{
						if(i>k)
						{
							aik=A[q1+i-k][k];
						}
						else
						{
							aik=A[q1+i-k][i];
						}
					}
					else
					{
						aik=0;
					}

				}
				if(((k - j + q2) < 0) || ((k-j+q2) >= p))
					bkj = 0;
				else
				{
					if(j<=k+q2&&j>=k-p2)
					{
						if(k>j)
						{
							bkj=B[q2+k-j][j];
						}
						else
						{
							bkj=B[q2+k-j][k];
						}
					}
					else
						bkj=0;
				}
			// cout<<aik<<" "<<bkj<<endl;
			C[i][j] += (aik * bkj);
		  	} 
	cout<<"**********************************************"<<endl;
	// printing the resultant matrix:-
	cout<<"\nThe resultant matrix C is:-\n";
	for(int i=0 ; i<m ; i++)
	{
		for(int j=0 ; j<p ; j++)
		{
			cout<<C[i][j]<<"	";
		}	
		cout<<endl;
	}	
	return 0;
}
