#include <bits/stdc++.h>
#include <time.h>
using namespace std;
int initialize(int nz,map<pair<int,int> , int> &A)
{
	int i=0,maxA=0;
	while(i<nz)	
	{
		int row = rand()%5;
		int col = rand()%5;
		int val = rand()%100 + 1;
		maxA = max(max(row,col),maxA);
		if(A[{row,col}] == 0)
		{
			A[{row,col}] = val;
			i++;	
		}
	}
	return maxA;

}
int main()
{
	srand(time(NULL));
	
	//structure for storing matrix A and B
	map<pair<int,int> , int> A,B;
	// To store result of matrice A*B
	vector<int> row_indices,col_indices,val_indices;

	int nz=max(rand()%25,10);
	int maxDim,i=0; 

	// initializing matrix A
	int maxA=initialize(nz,A);

	cout<<"\nInformation regarding Matrix A:-\n";	
	cout<<"row_index "<<"column_index "<<"	values\n";
	map<pair<int,int> , int> ::iterator it = A.begin();
	for(auto it:A)
	{
		cout<<it.first.first<<"		"<<it.first.second<<"		"<<it.second<<endl;
	}	

	// initializing matrix B
	int maxB=initialize(nz,B);

	cout<<"\nInformation regarding Matrix B:-\n";
	cout<<"row_index "<<"column_index "<<"	values\n";
	it = B.begin();
	for(auto it:B)
	{
		cout<<it.first.first<<"		"<<it.first.second<<"		"<<it.second<<endl;
	}	
	maxDim = max(maxA, maxB);
	cout<<"\nresultant product matrix:-\n";
    for(int i=0; i<=maxDim; i++)
    {
        for(int j=0; j<=maxDim; j++)
        {
            int x = 0;
            
            for(int k=0; k<=maxDim; k++)
            {
                pair <int,int> valA = make_pair(i,k);
                pair <int,int> valB = make_pair(k,j);
                
                if(A.find(valA) != A.end() && B.find(valB) != B.end())
                    x = x + A[valA]*B[valB];
            }
            if(x != 0)
            {
                row_indices.push_back(i);
                col_indices.push_back(j);
                val_indices.push_back(x);
            }
            cout<<x<<"\t";
        }
        cout<<endl;
    }

    cout<<endl;
    cout<<"Row Indices of the resultant product matrix:-\n";
    for(int i=0;i<row_indices.size();i++)
    {
   		cout<<row_indices[i]<<endl;
    }
   	cout<<endl;		
   	cout<<"\nColumn Indices of resultant product matrix:-\n";
    for(int i=0;i<col_indices.size();i++)
    {
   		cout<<col_indices[i]<<endl;
    }
   	cout<<endl;	
   	cout<<"\nValues of the resultant product matrix:-\n";
    for(int i=0;i<val_indices.size();i++)
    {
   		cout<<val_indices[i]<<endl;
    }
    return 0;
}