// for reference go through the http://citeseerx.ist.psu.edu/viewdoc/download?doi=10.1.1.334.9821&rep=rep1&type=pdf and https://www.youtube.com/watch?v=Qi7FcjN7nsc .

#include <bits/stdc++.h>
#include <time.h>
using namespace std;
int main()
{
	srand(time(NULL));
	int nz=0;
	//To store sparse matrice A and B
	map<pair<int,int>,int> A,B;

	int maxA=0,maxB=0,maxDim,nz_rows;
	cout<<"Enter the number of non-zero values for Matrix A:-";
	cin>>nz;
	vector<int> val_indices(nz,0),col_indices(nz,0),row_indices;
	cout<<endl;
	cout<<"Enter the values for matrix A:-";
	cout<<endl;
	for(int i=0;i<nz;i++)
	{
		cout<<i+1<<" :";
		int x;
		cin>>x;
		val_indices[i]=x;
	}	

	cout<<endl;
	cout<<"Enter the column indices for matrix A:-";
	for(int i=0;i<nz;i++)
	{
		cout<<i+1<<" :";
		int x;
		cin>>x;
		col_indices[i]=x;
	}	

	cout<<endl;
	cout<<"Enter no. of non-zero rows in matrix A:-";
	cin>>nz_rows;
	vector<int> v(nz_rows+1);
	
	cout<<endl;
	cout<<"Enter the row indentifying indices for matrix A:-";
	for(int i=0;i<nz_rows;i++)
	{
		cout<<i+1<<" :";
		int x;
		cin>>x;
		v[i]=x;
	}	
	v[nz_rows]=9999;
	// processing row pointer to make it useful for multiplication
	int row = 0;
	int pp=0;
	for(int i=1;i<=nz_rows;i++)
	{
		int x = v[i-1];	
		while(x!=v[i]&&pp<nz)
		{
			row_indices.push_back(row);
			x++;
			pp++;
		}
		row++;	
	}
	maxA=row-1;
	//storing matrix A in map
	for(int i=0 ; i<nz; i++)
	{
		row = row_indices[i];
		int col = col_indices[i];
		maxA = max(col,maxA);
		A[{row,col}] = val_indices[i];
	}	

	cout<<"\nInformation regarding Matrix A:-\n";
	cout<<"row_index "<<"column_index "<<"	values\n";
	for(auto it:A)
	{
		cout<<it.first.first<<"		"<<it.first.second<<"		"<<it.second<<endl;
	}	

// Matrix B
	vector<int> row_indices1;	
	
	cout<<endl;
	cout<<"Enter no. of non-zero values for Matrix B :-"<<endl;
	cin>>nz;

	cout<<endl;
	cout<<"Enter values for matrix B:-";
	for(int i=0;i<nz;i++)
	{
		cout<<i+1<<" :";
		int x;
		cin>>x;
		val_indices[i]=x;
	}	

	cout<<endl;
	cout<<"Enter col for matrix B:-";
	for(int i=0;i<nz;i++)
	{
		cout<<i+1<<" :";
		int x;
		cin>>x;
		col_indices[i]=x;
	}	

	cout<<"\nEnter no. of non-zero rows in matrix B:-";
	cin>>nz_rows;
	vector<int> v1(nz_rows); 	
	cout<<endl;		
	cout<<"Enter the row indentifying indices for matrix B:-";
	for(int i=0;i<nz_rows;i++)
	{
		cout<<i+1<<" :";
		int x;
		cin>>x;
		v1[i]=x;
	}	
	v1[nz_rows]=9999;
	// processing row pointer to make it useful for multiplication
	row = 0;
	pp=0;
	for(int i=1;i<=nz_rows;i++)
	{
		int x = v1[i-1];	
		while(x!=v1[i]&&pp<nz)
		{
			row_indices1.push_back(row);
			x++;
			pp++;
		}
		row++;	
	}
	
	//storing matrix B in map
	for(int i=0 ; i<nz; i++)
	{
		row = row_indices1[i];
		int col = col_indices[i];
		maxB = max(max(row,col),maxB);
		B[{row,col}] = val_indices[i];
	}		

	cout<<"\nInformation regarding Matrix B:-\n";
	cout<<"row_index "<<"column_index "<<"	values\n";
	for(auto it:B)
	{
		cout<<it.first.first<<"		"<<it.first.second<<"		"<<it.second<<endl;
	}	
	maxDim = max(maxA, maxB);

	// To store result of matrice A*B

	vector<int> row_indicess,col_indicess,val_indicess;

	cout<<"The resultant matrix is:-\n";
    for(int i=0; i<=maxDim; i++)
    {
        for(int j=0; j<=maxDim; j++)
        {
            int x = 0;
            
            for(int k=0; k<=maxDim; k++)
            {
                pair <int,int> valA = make_pair(i,k);
                pair <int,int> valB = make_pair(k,j);
                
                if(A.find(valA) != A.end() && B.find(valB) != B.end())
                {
                    x = x + A[valA]*B[valB];
                }
            }
            if(x != 0)
            {
                row_indicess.push_back(i);
                col_indicess.push_back(j);
                val_indicess.push_back(x);
            }
            cout<<x<<"\t";
        }
        cout<<endl;
    }

    cout<<endl;
    cout<<"Row Indices of the resultant product matrix:-\n";
    for(int i=0;i<row_indicess.size();i++)
    {
   		cout<<row_indicess[i]<<"	";
    }
   	cout<<endl;		

   	cout<<endl;		
   	cout<<"\nColumn Indices of resultant product matrix:-\n";
    for(int i=0;i<col_indicess.size();i++)
    {
   		cout<<col_indicess[i]<<"	";
    }
   	cout<<endl;	

   	cout<<endl;	
   	cout<<"\nValues of the resultant product matrix:-\n";
    for(int i=0;i<val_indicess.size();i++)
    {
   		cout<<val_indicess[i]<<"	";
    }
   	cout<<endl;		


    return 0;
}