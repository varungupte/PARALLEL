
#include<bits/stdc++.h>
using namespace std;
void LUHessenberg(int n,vector<vector<float> > &A)
{
	// Compute the LU Factorization
	for(int k=0;k<n-1;k++)
	{
		A[k+1][k]=A[k+1][k]/A[k][k];
		
		for(int j=k+1;j<n;j++)
		{
			A[k+1][j]=A[k+1][j]-A[k+1][j]*A[k][j];
		}
	}
}

#include <bits/stdc++.h>
#include <time.h>
using namespace std;
void initialize(int m,int n,vector<vector<float> > &A)
{
	for(int i=0 ; i<m ; i++)
	{
		for(int j=0 ; j<n ; j++)
		{
			A[i][j]=rand()%100+1;	
		}
	}
}

int main()
{
	srand(time(NULL));
	int n;
	n = rand()% 5 + 2;
	vector < vector<float> > A(n , vector<float> (n));

	//initializing the matrix A
	initialize(n,n,A);

	cout<<endl;
	cout<<"The matrix A is:-"<<endl;
	for(int i=0 ; i<n ; i++)
	{
		for(int j=0 ; j<n ; j++)
		{
			cout<<A[i][j]<<"	";
		}
		cout<<endl;
	}	

	// Computing the LU Factorization
	LUHessenberg(n,A);
	
	// L and U matrices
	vector < vector<float> > L(n , vector<float> (n)),U(n , vector<float> (n));
	
	cout<<endl;
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			if(i==j)
			{
				L[i][j] = 1;
				U[i][j] = A[i][j];
			}
			else if(i>j)
			{
				L[i][j] = A[i][j];
				U[i][j] = 0;
			}
			else
			{
				//if(i<j)
				U[i][j] = A[i][j];
				L[i][j] = 0;
			}
		}
	}
	// Printing L and U matrices
	cout<<endl;
	cout<<"Matrix L is:-"<<endl;
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			cout<<L[i][j]<<" ";
		}
		cout<<endl;
	}
	cout<<endl;
	cout<<"Matrix U is:-"<<endl;
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			cout<<U[i][j]<<" ";
		}
		cout<<endl;
	}

	return 0;
}	