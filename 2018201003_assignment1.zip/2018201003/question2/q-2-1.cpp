#include <bits/stdc++.h>
#include <time.h>
using namespace std;
void initialize(int m,int n,vector<vector<double> > &A)
{
	for(int i=0 ; i<m ; i++)
	{
		for(int j=0 ; j<n ; j++)
		{
			A[i][j]=rand()%100+1;	
		}
	}
}
void LUDecomposition(int n,vector<vector<double> > &A)
{
	//Compute the LU Factorization
	for(int k=0;k<n-1;k++)
	{
		for(int i=k+1;i<n;i++)
		{
			A[i][k]=A[i][k]/A[k][k];
		}
		
		for(int i=k+1;i<n;i++)
		{
			for(int j=k+1;j<n;j++)
			{
				A[i][j] =A[i][j]-A[i][k]*A[k][j];
			}
		}
	}
}

void forward_subs(int n, vector<vector<double> > &L,vector<double> &t)
{
	vector<double> b(n,20);
	t[0] = b[0]/L[0][0];
	for(int i=1;i<n;i++)
	{
		t[i] = b[i];
		for(int j=0;j<=i-1;j++)
		{
			t[i] = t[i] - (L[i][j]*t[j]);
		}
		t[i] = t[i]/L[i][i];
	}	
}

void backward_subs(int n, vector<vector<double> > &U,vector<double> &x)
{
	vector<double> b(n,20);
	x[n-1] = b[n-1]/U[n-1][n-1];
	for(int i=n-2;i>=0;i--)
	{
		x[i] = b[i];
		for(int j=i+1;j<n;j++)
		{
			x[i] =x[i] - U[i][j]*x[j];
		}
		x[i] = x[i]/U[i][i];
	}
}

int main()
{
	srand(time(NULL));
	int n;
	n = rand()% 5 + 2;
	vector < vector<double> > A(n ,vector<double> (n));
	//initializing the matrix A
	initialize(n,n,A);

	cout<<endl;
	cout<<"The matrix A is:-"<<endl;
	for(int i=0 ; i<n ; i++)
	{
		for(int j=0 ; j<n ; j++)
		{
			cout<<A[i][j]<<"	";
		}
		cout<<endl;
	}	

	// Computing the LU Factorization
	LUDecomposition(n,A);
	
	// L and U matrices
	vector < vector<double> > L(n , vector<double> (n)),U(n , vector<double> (n));
	
	cout<<endl;
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			if(i==j)
			{
				L[i][j] = 1;
				U[i][j] = A[i][j];
			}
			else if(i>j)
			{
				L[i][j] = A[i][j];
				U[i][j] = 0;
			}
			else
			{
				//if(i<j)
				U[i][j] = A[i][j];
				L[i][j] = 0;
			}
		}
	}
	// Solving Lx=b using forward substitution
	vector<double> x(n,0),x1(n,0);
	forward_subs(n,L,x);

	// Solving Ux=b using backward substitution
	backward_subs(n,U,x1);

	// Printing L and U matrices
	cout<<endl;
	cout<<"Matrix L is:-"<<endl;
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			cout<<L[i][j]<<" ";
		}
		cout<<endl;
	}
	cout<<endl;
	cout<<"Matrix U is:-"<<endl;
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			cout<<U[i][j]<<" ";
		}
		cout<<endl;
	}

	cout<<endl;
	cout<<"The values of matrix X in forward substitution using L is:-"<<endl;
	for(int i=0; i<n; i++)
	{
		cout<<x[i]<<endl;
	}

	cout<<endl;
	cout<<"The values of matrix x in backward substitution using U is:-"<<endl;
	for(int i=0; i<n; i++)
	{
		cout<<x1[i]<<" ";
	}

	return 0;
}	