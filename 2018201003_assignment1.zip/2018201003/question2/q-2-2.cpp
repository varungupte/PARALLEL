#include <bits/stdc++.h>
#include <time.h>
using namespace std;

void initialize(int m,int n,vector<vector<float> > &A)
{
	for(int i=0 ; i<m ; i++)
	{
		for(int j=0 ; j<n ; j++)
		{
			A[i][j]=rand()%100+1;	
		}
	}
}
void LU_Decomposition(int n,vector<vector<float> > &A)
{
	// Compute the LU Factorization
	for(int k=0;k<n-1;k++)
	{
		for(int i=k+1;i<n;i++)
		{
			A[i][k] /= A[k][k];
		}
		
		for(int i=k+1;i<n;i++)
		{
			for(int j=k+1;j<n;j++)
			{
				A[i][j] -= A[i][k]*A[k][j];
			}
		}
	}
}

void ForwardSubs(int n,vector<float> &t, vector<vector<float> > &L,vector<float> &b)
{
	
	t[0] = b[0]/L[0][0];
	for(int i=1;i<n;i++)
	{
		t[i] = b[i];
		for(int j=0;j<i;j++)
		{
			t[i] = t[i] - (L[i][j]*t[j]);
		}
		t[i] = t[i]/L[i][i];
	}	
}

void BackwardSubs(int n,vector<float> &x, vector<vector<float> > &U,vector<float> &b)
{
	if(b[n-1]==0)
	{
		x[n-1]=0;
	}
	else
	{
		x[n-1] = b[n-1]/U[n-1][n-1];
	}
	for(int i=n-2;i>=0;i--)
	{
		x[i] = b[i];
		for(int j=i+1;j<n;j++)
		{
			x[i] = x[i]-U[i][j]*x[j];
		}
		x[i] = x[i]/U[i][i];
	}
}
int main()
{
	srand(time(NULL));
	int n;
	cout<<"Enter the shape of the square matrix:-";
	cin>>n;	

	vector < vector<float> > A(n , vector<float> (n)),A_copy(n , vector<float> (n));
	initialize(n,n,A);
	cout<<endl;
	cout<<"The matrrix A is:-"<<endl;
	for(int i=0 ; i<n; i++)
	{
		for(int j=0 ; j<n; j++)
		{
			cout<<A[i][j]<<"	";
		}
		cout<<endl;
	}	
	A_copy = A; 					
	vector<float> b(n,0);			
	for(int i=0;i<n;i++)
	{
		b[i] = rand()%100 + 1;
	}
	cout<<"\nThe vector B is:-\n";
	for(int i=0;i<n;i++)
	{
		cout<<b[i]<<endl;
	}

	// Compute the LU Factorization
	LU_Decomposition(n,A);

	//Printing L and U matrices
	vector < vector<float> > L(n , vector<float> (n)),U(n , vector<float> (n));
	
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			if(i==j)
			{
				L[i][j] = 1;
				U[i][j] = A[i][j];
			}
			else if(i>j)
			{
				L[i][j] = A[i][j];
				U[i][j] = 0;
			}
			else
			{
				//if(i<j)
				U[i][j] = A[i][j];
				L[i][j] = 0;
			}
		}
	}
	cout<<endl<<"Matrix L is:-"<<endl;
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			cout<<L[i][j]<<" ";
		}
		cout<<endl;
	}
	cout<<endl<<"Matrix  U is:-"<<endl;
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			cout<<U[i][j]<<" ";
		}
		cout<<endl;
	}

	cout<<endl;
	cout<<"-------------------------------------------------------";
	
	// Solving Lt=b using forward substitution
	vector<float> t(n,0);
	ForwardSubs(n,t,L,b);

	cout<<endl;
	cout<<"Values of t in Lt = b are:-"<<endl;
	for(int i=0; i<n; i++)
	{
		cout<<t[i]<<endl;
	}

	// Solving Ux=t using forward substitution
	vector<float> x(n,0);
	BackwardSubs(n,x,U,t);

	cout<<"\nValues of x in Ux = t\n";
	for(int i=0; i<n; i++)
	{
		cout<<x[i]<<endl;
	}


	// compute ax-b
	double C[n][1];
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<1;j++)
			C[i][j]=0;
	}
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<1;j++)
		{
			for(int k=0;k<n;k++)
			{
				C[i][j]+=A_copy[i][k]*x[k];
			}
		}
	}
	cout<<endl;
	cout<<"Checking the solution by computuing ||Ax-b||:-"<<endl;
	for(int i=0;i<n;i++)
	{
		C[i][0] = abs(C[i][0]-b[i]);
		cout<<C[i][0]<<endl;
	}

	return 0;

}	