import numpy as np
import random
from numpy.linalg import inv
n = 3
def house(A,j):
	x = []
	for i in A:
		temp = []
		temp.append(i[j])
		x.append(temp)
	x = x[j:]
	e1 = []
	for i in range(n-j):
		temp=[]
		temp.append(0)
		e1.append(temp)

	e1[0][0]=1
	x = np.array(x)
	e1 = np.array(e1)
	v = x - np.linalg.norm(x)*e1
	beta = 2/np.dot(v.T , v)			
	z = v @ v.T
	v = np.array(v)
	H1 = np.identity(n-j) - beta * v @ v.T 
	H1 = np.array(H1)
	return H1	

def myQR(A):
	c = 0
	Q = np.identity(n)
	global H
	for i in range(n-1):
		H2=house(A,c)
		A = np.array(A)
		A1=A[c:,c:]
		A1 = H2 @ A1
		for i in range(c,n):
			for i1 in range(c,n):
				A[i][i1]=A1[i-c][i1-c]
		c = c + 1
	return A


def backward(x,n,m,b1,R):
	x[m-1] = b1[m - 1][0] / R[m - 1][m - 1]
	i = n - 2
	while i>=0:
		x[i] = b1[i][0]
		for j in range(i+1,m):
			x[i] =x[i]-(R[i][j] * x[j])
		x[i] = x[i]/R[i][i]	
		i=i-1
	return x


A = []
m=2
A=[[3,-2],[0,3],[4,4]]
Acopy = [[3,-2],[0,3],[4,4]]
b=[3,5,4]


# Aug=[]
for i in range(n):
	A[i].append(b[i])

print("the Matrix A is :-")
A = np.array(A)
for i in A:
	print(i)

R = myQR(A)			
R_inv=inv(np.array(R))

Q=A@R_inv

b2=[]

for i in b:
	temp=[]
	temp.append(i)
	b2.append(temp)

b2=np.array(b2)


b1=Q.T@b2
R=R[0:m,0:m]

x = [0]*m	
x=backward(x,n,m,b1,R)

x1=[]
for i in x:
	temp=[]
	temp.append(i)
	x1.append(temp)


x1=np.array(x1)
Acopy=np.array(Acopy)

print("Matrix Q is:-")
for i in Q:
	print(i)

print("Matrix R is:-")
for i in R:
	print(i)

print("Matrix X is:-")
for i in x:
	print(i)

print("Matrix B is:-")
for i in b:
	print(i)

# print(b2-Acopy@x1)
