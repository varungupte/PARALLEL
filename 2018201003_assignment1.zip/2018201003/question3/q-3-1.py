import numpy as np
import random

def house(A):
    x = []
    for i in A:
        x.append(i[0])
    print "\nHouse-Holder matrix of matrix A is:-\n"
    e1 = np.zeros(n)    
    e1[1] = 1
    v = x - np.linalg.norm(x)*e1
    print v
    beta = 2/np.dot(v.T , v)
    H = np.identity(n) - beta * v * v.T        
    #printing the house_holder matrix
    for row in H:
        print row


# A = []
# #randomly defining the shape of A
# n = random.randint(2,6)         

# #randomly initializing the value of matrix A
# for i in range(n):              
#     temp = []
#     for j in range(n):
#         temp.append(random.randint(0,100))
#     A.append(temp)
n=3
A=[[2,-2,18],[2,1,0],[1,2,0]]
print "Matrix A is:-\n"
A = np.array(A)
for row in A:
    print row
#calling the house function. It will print the household matrices
house(A)            